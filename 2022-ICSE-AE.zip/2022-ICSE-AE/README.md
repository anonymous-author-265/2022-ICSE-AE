# Retrieving Data Constraint Implementations Using Fine-Grained Code Patterns - Artifact

This artifact contains all the data and code necessary for replicating the results of the accepted ICSE 2022 submission "Retrieving Data Constraint Implementations Using Fine-Grained Code Patterns".

The artifact can be found at the following address: <https://doi.org/10.5281/zenodo.6087022>

## Using the Artifact

To use the artifact to replicate the results of the paper:

1. Download the artifact ZIP file and extract it to a location, which we will call `ARTIFACT_PATH`.

2. Follow the instructions found in `ARTIFACT_PATH/code/README.md` (we repeat them here for convenience).

3. Make sure that the current working directory is `ARTIFACT_PATH/code`.

4. Install JDK 11: `sudo apt-get install openjdk-11-jdk`.

5. Run the evaluation: `./evaluate-lasso ../replication`.

## Extending the Artifact

We designed the code of our tool to be flexible, so that it can both be extended to provide additional functionality, and also can be seamlessly used with new data. Please see the README files for the code (`ARTIFACT_PATH/code/README.md`) and data(`ARTIFACT_PATH/data/README.md`) for instructions on how to extend Lasso and how to expand the data set, respectively.

