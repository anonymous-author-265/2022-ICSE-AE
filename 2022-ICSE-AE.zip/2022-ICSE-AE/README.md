# Retrieving Data Constraint Implementations Using Fine-Grained Code Patterns - Artifact

This artifact contains all the data and code necessary for replicating the results of the accepted ICSE 2022 submission "Retrieving Data Constraint Implementations Using Fine-Grained Code Patterns".

The artifact can be found at the following address: <https://doi.org/10.5281/zenodo.5915651>

## Using the Artifact

To use the artifact to replicate the results of the paper:

1. Download the artifact ZIP file and extract it to a location, which we will call `ARTIFACT_PATH`.

2. Follow the instructions found in `ARTIFACT_PATH/code/README.md` (we repeat them here for convenience).

3. Make sure that the current working directory is `ARTIFACT_PATH/code`.

4. Install JDK 11: `sudo apt-get install openjdk-11-jdk`.

5. Run the evaluation: `./evaluate-lasso ../replication`.


