# Installation

To install the artifact simply download the ZIP file at <https://doi.org/10.5281/zenodo.5915651> and then extract it to any location on your machine.

## Testing the Artifact

To use the artifact to replicate the results of the paper:

1. Download the artifact ZIP file and extract it to a location, which we will call `ARTIFACT_PATH`.

2. Follow the instructions found in `ARTIFACT_PATH/code/README.md` (we repeat them here for convenience).

3. Make sure that the current working directory is `ARTIFACT_PATH/code`.

4. Install JDK 11: `sudo apt-get install openjdk-11-jdk`.

5. Run the evaluation: `./evaluate-lasso ../replication`.

Note that the evaluation will take *1 hour* or longer on single or dual-core systems.

### Validating

To confirm that the execution is proceeding correctly, note the messages:

- "Processing scenario:"

- "Setting up index for"

- "Searching"
