# Requirements

## Operating System

Windows or Linux system with Java Development Kit (JDK) 11.

## Hardware

At least 8 GB of *Java heap space* are required to replicate the results of the paper, so  at least 12 GB RAM are recommended for the evaluation environment.
