# Badges Claimed

1. **Available**: We make the data and source code available on a public repository which assigns a DOI.

2. **Reusable**: We include all data necessary to replicate the results of our research, as well as all the source code used to perform the evaluation. The code is also set up so that it can be run with a single command for ease of replication.
